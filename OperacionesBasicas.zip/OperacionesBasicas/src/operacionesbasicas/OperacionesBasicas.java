/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package operacionesbasicas;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class OperacionesBasicas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner scanner = new Scanner(System.in);

        // Solicitar números al usuario
        System.out.print("Ingrese el primer número: ");
        double numero1 = scanner.nextDouble();

        System.out.print("Ingrese el segundo número: ");
        double numero2 = scanner.nextDouble();

        // Crear objeto de la clase Operaciones
        Operaciones operaciones = new Operaciones(numero1, numero2);

        // Menú de opciones
        int opcion;
        do {
            System.out.println("\nSeleccione una operación:");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multiplicación");
            System.out.println("4. División");
            System.out.println("5. Salir");
            System.out.print("Ingrese su opción: ");
            opcion = scanner.nextInt();

            // Ejecutar la opción seleccionada
            switch (opcion) {
                case 1:
                    System.out.println("Resultado de la suma: " + operaciones.sumar());
                    break;
                case 2:
                    System.out.println("Resultado de la resta: " + operaciones.restar());
                    break;
                case 3:
                    System.out.println("Resultado de la multiplicación: " + operaciones.multiplicar());
                    break;
                case 4:
                    System.out.println("Resultado de la división: " + operaciones.dividir());
                    break;
                case 5:
                    System.out.println("¡Gracias por usar el programa!");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        } while (opcion != 5);

        scanner.close();
    
    }
    
}
